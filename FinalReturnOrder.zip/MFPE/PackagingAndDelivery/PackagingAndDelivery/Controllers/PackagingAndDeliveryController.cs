﻿using Microsoft.AspNetCore.Mvc;
using PackagingAndDelivery.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace PackagingAndDelivery.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PackagingAndDeliveryController : ControllerBase
    {
        private readonly IRepo _repo;
        public PackagingAndDeliveryController(IRepo repo)
        {
            _repo = repo;   
        }
        [HttpGet]
        public ActionResult<double> PackagingDeliveryCharge(string item,int count)
        {
            double total = _repo.PackagingDeliveryCharge(item, count);
            return Ok(total);
        }
        
    }
}
