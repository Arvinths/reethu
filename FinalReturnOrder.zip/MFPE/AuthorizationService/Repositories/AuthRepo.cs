﻿using AuthorizationService.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AuthorizationService.Repositories
{
    public class AuthRepo:IAuthRepo
    {
        public List<User> users;
        public AuthRepo()
        {
            users = new List<User>()
            {
                new User(){username="user",password="user123"},new User(){username="arvi",password="arvi123"},
                new User(){username="nisha",password="nisha123"},new User(){username="rama",password="rama123"},
                new User(){username="battu",password="battu123"},new User(){username="Singh",password="singh123"},
                new User(){username="dee",password="dee123"},new User(){username="kannu",password="kannu123"},
                new User(){username="uday",password="uday123"},new User(){username="Raja",password="raja123"},  
            };
        }
        public User GetUser(User user)
        {
            var userinfo = users.FirstOrDefault(x => x.username == user.username & x.password == user.password);
            return userinfo;
        }
    }
}
