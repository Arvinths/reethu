﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ReturnOrder.Models
{
    public class ErrorDto
    {
        public string Id { get; set; }
        public string Message { get; set; }
    }
}
