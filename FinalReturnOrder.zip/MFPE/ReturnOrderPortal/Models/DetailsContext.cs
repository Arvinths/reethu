﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ReturnOrderPortal.Models
{
    public class DetailsContext:DbContext
    {
        public DetailsContext(DbContextOptions options):base(options)
        {

        }
        public DbSet<PaymentDetails> PaymentDetail { get; set; }
    }
}
