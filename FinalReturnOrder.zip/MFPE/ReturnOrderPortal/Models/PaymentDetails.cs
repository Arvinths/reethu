﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ReturnOrderPortal.Models
{
    public class PaymentDetails
    {
        [Key]
        public int Id { get; set; }
        public int RequestId { get; set; }
        public string UserName { get; set; }
        public string ComponentName { get; set; }
        public Double ProcessingCharge { get; set; }
        [Display(Name ="Package and Delivery charge")]
        public Double PackageDeliveryCharge { get; set; }
        public int Quantity { get; set; }
        public DateTime DateOfDelivery { get; set; }

    }
}
