﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ReturnOrderPortal.Models
{
    public class ProcessRequestDTO
    {
        [Required(ErrorMessage ="Enter the name")]
        public string Name { get; set; }

        [Required(ErrorMessage ="Enter the Phone Number")]
        [RegularExpression(@"(9|8|7|6)\d{9}",ErrorMessage ="Invalid Phone Number")]
        public string ConactNumber { get; set; }

        [Required(ErrorMessage ="Enter Credit Card Number")]
        [RegularExpression(@"(\d{16})",ErrorMessage ="Invalid CardNumber")]
        public string CreditCardNumber { get; set; }

        [Required(ErrorMessage = "Choose the type")]
        public string ComponentType { get; set; }

        [Required(ErrorMessage = "Enter the Component Name")]
        public string ComponentName { get; set; }
        public int Qunatity { get; set; }
        public bool IsPriorityRequest { get; set; }
    }
}
