﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ReturnOrderPortal.Models
{
    public class ApplicationDTO
    {
        public int RequestId { get; set; }
        public string UserName { get; set; }
        public string ComponentName { get; set; }
        public double ProcessCharge { get; set; }
        public string CardNumber { get; set; }
        public double CardLimit { get; set; }
        public double PackageDeliveryCharge { get; set; }
        public int Quantity { get; set; }
        public DateTime DeliveryDate { get; set; }


    }
}
