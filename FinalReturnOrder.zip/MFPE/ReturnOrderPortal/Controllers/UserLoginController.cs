﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using ReturnOrderLogin.Models;
using ReturnOrderLogin.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ReturnOrderLogin.Controllers
{
    public class UserLoginController : Controller
    {
        private IConfiguration _configuration;
        private IAuthRepo _repo;
        public UserLoginController(IConfiguration configuration,IAuthRepo repo)
        {
            _configuration = configuration;
            _repo = repo;
        }
        [HttpGet]
        public IActionResult Login()
        {
                HttpContext.Response.Cookies.Delete("Token");  
                return View();
           
        }
        [HttpPost]
        public IActionResult Login(User user)
        {
            try
            {
                var token = _repo.GetToken(user);

                if (user.username=="u")
                {
                    //HttpContext.Response.Cookies.Append("Token", token);
                    return RedirectToRoute(new { controller = "ReturnOrder", action = "AddDetails" });
                }

                ViewBag.Flag = 1;
                return View("Login");
            }
            catch (Exception e)
            {
                return View("Error"+e);
            }

        }
    }
}
