﻿using ReturnOrderPortal.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using ReturnOrderPortal.Service;

namespace ReturnOrderPortal.Controllers
{
    public class ReturnOrderController : Controller
    {
        private readonly DetailsContext _context;
        public ReturnOrderController(DetailsContext context)
        {
            _context = context;
        }
        public IActionResult AddDetails()
        {
            var list = new List<string>() { "Integral", "Accessory" };
            ViewBag.list = list;
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> GetDetails(ProcessRequestDTO requestDTO)
        {
            
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri("http://localhost:52777");
                var token = HttpContext.Request.Cookies["Token"];
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
                StringContent content = new StringContent(JsonConvert.SerializeObject(requestDTO), Encoding.UTF8, "application/json");
                var myResponse = await client.PostAsync("api/ComponentProcessing/ProcessDetails", content);
                if (myResponse.StatusCode == HttpStatusCode.OK)
                {
                    ProcessResponseDTO processResponse = await myResponse.Content.ReadAsAsync<ProcessResponseDTO>();
                    ViewBag.CardNumber = requestDTO.CreditCardNumber;
                    ViewBag.UserName = requestDTO.Name;
                    ViewBag.ComponentName = requestDTO.ComponentName;
                    ViewBag.Quantity = requestDTO.Qunatity;
                    var tempLimit = await client.GetAsync("api/ComponentProcessing/"+requestDTO.CreditCardNumber);
                    ViewBag.CardLimit = await tempLimit.Content.ReadAsAsync<double>();
                    return View(processResponse);
                }

            }
            catch
            {
                ModelState.Clear();
                ModelState.AddModelError("Error", "Error in Sending the request");
                return View();
            }
            return View();
        }
        /*
         
        
        */
        [HttpGet]
        public async Task<IActionResult> ProcessPayment(ApplicationDTO appDTO)
        {
            
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri("http://localhost:52777");
                var token = HttpContext.Request.Cookies["Token"];
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
                ObjCreator objCreator = new ObjCreator();
                ProcessPaymentDTO paymentDTO = objCreator.GetProcessPaymentObj(appDTO);
                PaymentDetails paymentDetails = objCreator.GetPaymentDetailsObj(appDTO);
                StringContent content = new StringContent(JsonConvert.SerializeObject(paymentDTO), Encoding.UTF8, "application/json");
                var myResponse = await client.PostAsync("api/ComponentProcessing", content);
                if (myResponse.StatusCode == HttpStatusCode.OK)
                {
                    ViewBag.Flag = 1;
                    ViewBag.Balance = await myResponse.Content.ReadAsStringAsync();
                    AddToDb addToDb = new AddToDb(_context);
                    addToDb.AddData(paymentDetails);
                    ViewBag.Name = appDTO.UserName;
                    return View();
                }
                else
                {
                    ViewBag.Flag = 0;
                    ViewBag.Message = await myResponse.Content.ReadAsStringAsync();
                    return View();
                }
            }
            catch
            {
                ModelState.Clear();
                ModelState.AddModelError("Error", "Error in Sending the request");
                return View();
            }
        }
        [HttpGet]
        public IActionResult ShowDetails(string name)
        {
            RetriveData retriveData = new RetriveData(_context);
            var details =retriveData.GetUserDetails(name);
            return View(details);
        }
            
    }
}
