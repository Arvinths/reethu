﻿using ReturnOrderPortal.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ReturnOrderPortal.Service
{
    public class AddToDb
    {
        private readonly DetailsContext _context;
        public AddToDb(DetailsContext context )
        {
            _context = context;
        }
        public bool AddData(PaymentDetails paymentDetails)
        {
            try
            {
                _context.PaymentDetail.Add(paymentDetails);
                _context.SaveChanges();
                return true;
            }
            catch(Exception)
            {
                return false;
            }
        }
    }
}
