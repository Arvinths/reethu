﻿using ReturnOrderPortal.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ReturnOrderPortal.Service
{
    public class RetriveData
    {
        private readonly DetailsContext _context;
        public RetriveData(DetailsContext context)
        {
            _context = context;
        }
        public IEnumerable<PaymentDetails> GetUserDetails(string name)
        {
            var details = _context.PaymentDetail.Where(p => p.UserName == name).ToList();
            return details;
        }
    }
}
