﻿using ReturnOrderPortal.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ReturnOrderPortal.Service
{
    public class ObjCreator
    {
        public PaymentDetails GetPaymentDetailsObj(ApplicationDTO appDTO)
        {
            PaymentDetails paymentDetails = new PaymentDetails();
            paymentDetails.PackageDeliveryCharge = appDTO.PackageDeliveryCharge;
            paymentDetails.UserName = appDTO.UserName;
            paymentDetails.ComponentName = appDTO.ComponentName;
            paymentDetails.Quantity = appDTO.Quantity;
            paymentDetails.DateOfDelivery = appDTO.DeliveryDate;
            paymentDetails.ProcessingCharge = appDTO.ProcessCharge;
            paymentDetails.RequestId = appDTO.RequestId;
            return paymentDetails;
        }
        public ProcessPaymentDTO GetProcessPaymentObj(ApplicationDTO appDTO)
        {
            ProcessPaymentDTO paymentDTO = new ProcessPaymentDTO();
            paymentDTO.CardNumber = appDTO.CardNumber;
            paymentDTO.CardLimit = appDTO.CardLimit;
            paymentDTO.RequestId = appDTO.RequestId;
            paymentDTO.ProcessCharge = appDTO.ProcessCharge;
            return paymentDTO;
        }
    }
}
